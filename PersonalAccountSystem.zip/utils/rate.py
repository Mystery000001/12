# coding=utf-8
# zengyiqi

# 汇率数据爬虫，网址：http://www.boc.cn/sourcedb/whpj/

import requests
from lxml import etree
from decimal import *


def getRate():
    def getnum(i, html):
        strxpath = '//table[@align="left"]/tr[' + str(i) + ']/td'
        # 对元素和属性进行遍历
        html_data = html.xpath(strxpath)
        x = html_data[5].text
        return x

    request = requests.get("http://www.boc.cn/sourcedb/whpj/")

    request.encoding = "utf-8"
    htmlresult = request.text.encode("utf-8")
    # 解析网页结构
    html = etree.HTML(htmlresult)

    # 循环获取
    m = 0
    for k in range(2, 28, 1):
        try:
            if k == 8:
                o = float(getnum(k, html)) / 100
            if k == 9:
                y = float(getnum(k, html)) / 100
            if k == 27:
                m = float(getnum(k, html)) / 100
        except:
            o = 7.1
            y = 8.3
            m = 6.6

    # 处理精度丢失
    o = Decimal(o).quantize(Decimal('0.0000'))
    y = Decimal(y).quantize(Decimal('0.0000'))
    m = Decimal(m).quantize(Decimal('0.0000'))
    print(o, y, m)
    return o, y, m


if __name__ == '__main__':
    getRate()
