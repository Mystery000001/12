# coding=utf-8
# zengyiqi

# 登录数据处理

import json


class Login:
    def __init__(self):
        pass

    def login(self, username, password):
        users = None
        filename = "../db/" + "User" + ".json"
        with open(filename, 'r', encoding='UTF-8') as fp:
            users = fp.read()
        dic_user = json.loads(users)
        flag = False
        for d in dic_user:
            if d['username'] == username and d['password'] == password:
                flag = True

        return flag
