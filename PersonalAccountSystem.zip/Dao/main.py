# coding=utf-8
# zengyiqi

# 主页数据处理

import os
from tkinter import messagebox


class Main:
    def __init__(self):
        pass

    # 记账功能 实现
    def save_data(self, id, gos, type, money, note):
        self.account_list = []
        self.student = {'time': id, 'gos': gos, 'type': type, 'money': money, 'note': note}
        self.account_list.append(self.student)
        # self.status.set('录入成功')
        try:
            stu_txt = open('../db/account.txt', 'a', encoding='UTF-8')
        except:
            stu_txt = open('../db/account.txt', 'w', encoding='UTF-8')
        for item in self.account_list:
            stu_txt.write(str(item) + '\n')
        stu_txt.close()

    # 按日期查找账单 实现
    def get_account_day(self, time):
        account_query = []
        with open('../db/account.txt', 'r', encoding='UTF-8') as id_search_file:
            account_info = id_search_file.readlines()
            for item in account_info:
                info = dict(eval(item))
                if time != '':
                    if time in info['time']:
                        account_query.append(info)
        return account_query

    # 按消费项目查找账单 实现
    def get_account_type(self, type):
        account_query = []
        with open('../db/account.txt', 'r', encoding='UTF-8') as id_search_file:
            account_info = id_search_file.readlines()
            for item in account_info:
                info = dict(eval(item))
                if type != '':
                    if type == info['type']:
                        account_query.append(info)
        return account_query

    # 按支出/收入查找账单 实现
    def get_account_gos(self, gos):
        account_query = []
        with open('../db/account.txt', 'r', encoding='UTF-8') as id_search_file:
            account_info = id_search_file.readlines()
            for item in account_info:
                info = dict(eval(item))
                if gos != '':
                    if gos == info['gos']:
                        account_query.append(info)
        print(account_query[0])

        return account_query

    # 查找所有账单 实现
    def get_account_all(self):
        account_query = []
        with open('../db/account.txt', 'r', encoding='UTF-8') as id_search_file:
            account_info = id_search_file.readlines()
            for item in account_info:
                info = dict(eval(item))
                account_query.append(info)
        return account_query

    # 删除功能 实现
    def delete_account(self, time):
        if os.path.exists('../db/account.txt'):
            with open('../db/account.txt', 'r', encoding='UTF-8') as r_file:
                account_info = r_file.readlines()
        else:
            messagebox.showwarning(message='account文件不存在')

        if account_info:
            with open('../db/account.txt', 'w', encoding='UTF-8') as w_file:
                info = []
                flag = False
                for item in account_info:
                    info = dict(eval(item))
                    if info['time'] != time:
                        w_file.write(str(info) + '\n')
                    else:
                        flag = True
                if flag:
                    messagebox.showwarning(message='删除成功')
                else:
                    messagebox.showwarning(message='删除失败')

    # 修改功能 实现
    def edit_account(self, time, gos, type, money, note):
        if os.path.exists('../db/account.txt'):
            with open('../db/account.txt', 'r', encoding='UTF-8') as r_file:
                account_info = r_file.readlines()
        else:
            messagebox.showwarning(message='account文件不存在')

        if account_info:
            with open('../db/account.txt', 'w', encoding='UTF-8') as w_file:
                for item in account_info:
                    info = dict(eval(item))
                    if info['time'] != time:
                        w_file.write(str(info) + '\n')
                    else:
                        info['time'] = time
                        info['gos'] = gos
                        info['type'] = type
                        info['money'] = money
                        info['note'] = note
                        w_file.write(str(info) + "\n")

    # 各消费项目金额统计 实现
    def get_account_type_total(self):
        account_query = []
        with open('../db/account.txt', 'r', encoding='UTF-8') as search_file:
            account_info = search_file.readlines()
            # '餐饮', '购物', '娱乐', '交通', '学习', '其它'
            canyin_total = 0
            gouwu_total = 0
            yule_total = 0
            jiaotong_total = 0
            xuexi_total = 0
            qita_total = 0
            total = 0
            for item in account_info:
                info = dict(eval(item))
                account_query.append(info)
            for item in account_query:
                if item['type'] == '餐饮':
                    canyin_total += float(item['money'])
                    continue
                elif item['type'] == '购物':
                    gouwu_total += float(item['money'])
                    continue
                elif item['type'] == '娱乐':
                    yule_total += float(item['money'])
                    continue
                elif item['type'] == '交通':
                    jiaotong_total += float(item['money'])
                    continue
                elif item['type'] == '学习':
                    xuexi_total += float(item['money'])
                    continue
                elif item['type'] == '其它':
                    qita_total += float(item['money'])
                    continue
            total += canyin_total + gouwu_total + yule_total + jiaotong_total + xuexi_total + qita_total

        info = str(canyin_total) + ',' + str(gouwu_total) + ',' + str(yule_total) + ',' + str(
            jiaotong_total) + ',' + str(xuexi_total) + ',' + str(qita_total)
        return info, canyin_total, gouwu_total, yule_total, jiaotong_total, xuexi_total, qita_total
