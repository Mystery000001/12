# coding=utf-8
# zengyiqi

# 主页各分页显示/隐藏控制

import tkinter as tk
from view.mainViewControl import AboutFrame, SearchTypeFrame, InsertFrame, SearchDayFrame, SearchGosFrame, TotalFrame, RateFrame


class MainView:
    def __init__(self):
        self.root = tk.Tk()
        width = 600
        height = 400
        self.root.geometry(f'{width}x{height}')

        # 2、计算中心坐标点
        screen_width = self.root.winfo_screenwidth() / 2 - width / 2
        screen_height = self.root.winfo_screenheight() / 2 - height / 2

        # 移动到中心点
        self.root.geometry(f"+{int(screen_width)}+{int(screen_height)}")
        self.root.title('个人消费记账系统')
        # self.root.geometry('600x400')
        self.create_page()
        self.insert_frame = InsertFrame(self.root)
        self.search_day_frame = SearchDayFrame(self.root)
        self.search_type_frame = SearchTypeFrame(self.root)
        self.search_gos_frame = SearchGosFrame(self.root)
        self.about_frame = AboutFrame(self.root)
        self.total_frame = TotalFrame(self.root)
        self.rate_frame = RateFrame(self.root)

    def create_page(self):
        menubar = tk.Menu(self.root)
        menubar.add_cascade(label='记账', command=self.show_insert)
        menubar.add_command(label='按日期查询(管理账目)', command=self.show_day_search)
        menubar.add_command(label='按消费项目查询', command=self.show_type_search)
        menubar.add_command(label='收入/支出', command=self.show_gos_search)
        menubar.add_command(label='统计', command=self.show_total)
        menubar.add_command(label='汇率计算', command=self.show_rate)
        menubar.add_command(label='说明', command=self.show_about)
        self.root['menu'] = menubar

    def show_about(self):
        self.about_frame.pack()
        self.search_type_frame.pack_forget()
        self.insert_frame.pack_forget()
        self.search_day_frame.pack_forget()
        self.search_gos_frame.pack_forget()
        self.total_frame.pack_forget()
        self.rate_frame.pack_forget()

    def show_insert(self):
        self.about_frame.pack_forget()
        self.search_type_frame.pack_forget()
        self.insert_frame.pack()
        self.search_day_frame.pack_forget()
        self.search_gos_frame.pack_forget()
        self.total_frame.pack_forget()
        self.rate_frame.pack_forget()
        pass

    def show_day_search(self):
        self.about_frame.pack_forget()
        self.search_type_frame.pack_forget()
        self.insert_frame.pack_forget()
        self.search_day_frame.pack()
        self.search_gos_frame.pack_forget()
        self.total_frame.pack_forget()
        self.rate_frame.pack_forget()
        pass

    def show_gos_search(self):
        self.about_frame.pack_forget()
        self.search_type_frame.pack_forget()
        self.insert_frame.pack_forget()
        self.search_day_frame.pack_forget()
        self.search_gos_frame.pack()
        self.total_frame.pack_forget()
        self.rate_frame.pack_forget()
        pass

    def show_type_search(self):
        self.about_frame.pack_forget()
        self.search_type_frame.pack()
        self.insert_frame.pack_forget()
        self.search_day_frame.pack_forget()
        self.search_gos_frame.pack_forget()
        self.total_frame.pack_forget()
        self.rate_frame.pack_forget()
        pass

    def show_total(self):
        self.about_frame.pack_forget()
        self.search_type_frame.pack_forget()
        self.insert_frame.pack_forget()
        self.search_day_frame.pack_forget()
        self.search_gos_frame.pack_forget()
        self.total_frame.pack()
        self.rate_frame.pack_forget()
        pass

    def show_rate(self):
        self.about_frame.pack_forget()
        self.search_type_frame.pack_forget()
        self.insert_frame.pack_forget()
        self.search_day_frame.pack_forget()
        self.search_gos_frame.pack_forget()
        self.total_frame.pack_forget()
        self.rate_frame.pack()
        pass
