# coding=utf-8
# zengyiqi

# 登录视图

from tkinter import *
from tkinter import messagebox
from tkinter import ttk
import hashlib
from Dao.Login import Login
from view.registerView import Register
from view.mainView import MainView


class LoginView(Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.pack()
        self.createWidget()

    def createWidget(self):
        self.username = StringVar()
        self.password = StringVar()

        Label(self, height=5, text="欢迎使用个人记账系统 ^v^", font=("黑体", 18)).grid(row=0, column=0, columnspan=3)

        Label(self, text='账  号：', font=('', 15)).grid(row=1, column=1, pady=10)
        self.entry01 = Entry(self, textvariable=self.username)
        self.entry01.grid(row=1, column=2, pady=10)

        Label(self, text='密  码：', font=('', 15)).grid(row=2, column=1, pady=10)
        self.entry02 = Entry(self, show='*', textvariable=self.password)
        self.entry02.grid(row=2, column=2, pady=10)

        self.button01 = Button(self, text='登录', command=self.login, font=('', 14), background='#1E90FF', relief=FLAT)
        self.button01.grid(row=3, column=1, pady=20)
        self.button01.config(fg="#FFFFFF")
        self.button02 = Button(self, text='注册', command=self.register, font=('', 14), background='#1E90FF', relief=FLAT)
        self.button02.grid(row=3, column=2, pady=10)
        self.button02.config(fg="#FFFFFF")

    # 登录事件
    def login(self):
        l = Login()
        username = self.entry01.get()
        password = hashlib.md5()
        password.update(self.entry02.get().encode('UTF-8'))
        flag = l.login(username, password.hexdigest())

        # flag = True
        if flag:
            self.master.destroy()
            MainView()
            # Accounting()
        else:
            messagebox.showwarning(message='用户名或密码错误，请重新输入！')

    # 注册事件
    def register(self):
        self.master.destroy()
        Register()


if __name__ == '__main__':
    root = Tk()

    # 设置窗口居中
    # 1、先设置窗口大小
    width = 400
    height = 350
    root.geometry(f'{width}x{height}')

    # 2、计算中心坐标点
    screen_width = root.winfo_screenwidth() / 2 - width / 2
    screen_height = root.winfo_screenheight() / 2 - height / 2

    # 移动到中心点
    root.geometry(f"+{int(screen_width)}+{int(screen_height)}")

    root.title("个人记账系统 v0.0.1By_zyq")
    LoginView(master=root)

    root.mainloop()
