# coding=utf-8
# zengyiqi

# 注册视图

import json

import ttkbootstrap as tk
from tkinter import messagebox
from tkinter import *
from view.loginView import *
import hashlib
from decimal import *
from ttkbootstrap import Style
from ttkbootstrap.constants import *


class Register:
    def __init__(self):
        super().__init__()

        root = tk.Window(
            title="注册",  # 设置窗口的标题
            size=(500, 500),  # 窗口的大小
            position=(710, 290),  # 窗口所在的位置
            # position=(760, 340),  # 窗口所在的位置（教室机子）
            minsize=(0, 0),  # 窗口的最小宽高
            maxsize=(1920, 1080),  # 窗口的最大宽高
            resizable=None,  # 设置窗口是否可以更改大小
            alpha=1.0,  # 设置窗口的透明度(0.0完全透明）
        )

        username_str_var = tk.StringVar()
        password_str_var = tk.StringVar()

        tk.Label(root, width=10).grid(pady=20)
        tk.Label(root, text='用户名：', bootstyle="primary").grid(row=1, column=1, sticky=tk.W, pady=10)
        tk.Entry(root, textvariable=username_str_var).grid(row=1, column=2, sticky=tk.W)
        tk.Label(root, text='密 码：', bootstyle="primary").grid(row=2, column=1, sticky=tk.W, pady=10)
        tk.Entry(root, textvariable=password_str_var).grid(row=2, column=2, sticky=tk.W)

        # 0 女 1 男
        gender_str_var = tk.IntVar()

        tk.Label(root, text='性别：', bootstyle="primary").grid(row=4, column=1, sticky=tk.W, pady=10)
        radio_frame = tk.Frame()
        radio_frame.grid(row=4, column=2, sticky=tk.W)
        tk.Radiobutton(radio_frame, text='男', variable=gender_str_var, value=0).pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(radio_frame, text='女', variable=gender_str_var, value=1).pack(side=tk.LEFT, padx=5)

        hobby_list = [
            [tk.IntVar(), '美食'],
            [tk.IntVar(), '旅游'],
            [tk.IntVar(), '购物'],
        ]
        tk.Label(root, text='兴趣：', bootstyle="primary").grid(row=6, column=1, sticky=tk.W, pady=10)
        check_frame = tk.Frame()
        check_frame.grid(row=6, column=2, sticky=tk.W)
        tk.Checkbutton(check_frame, text=hobby_list[0][1], variable=hobby_list[0][0], bootstyle="round-toggle").pack(
            side=tk.LEFT, padx=5)
        tk.Checkbutton(check_frame, text=hobby_list[1][1], variable=hobby_list[1][0], bootstyle="round-toggle").pack(
            side=tk.LEFT, padx=5)
        tk.Checkbutton(check_frame, text=hobby_list[2][1], variable=hobby_list[2][0], bootstyle="round-toggle").pack(
            side=tk.LEFT, padx=5)

        tk.Label(root, text='生日：', bootstyle="primary").grid(row=7, column=1, sticky=tk.W, pady=10)
        data_entry = tk.DateEntry(bootstyle="primary")
        data_entry.grid(row=7, column=2, sticky=tk.W, pady=10)
        print(data_entry.entry.get())

        def get_info():
            password = hashlib.md5()
            password.update(password_str_var.get().encode('UTF-8'))
            data = {
                "username": username_str_var.get(),
                "password": password.hexdigest(),
                "sex": gender_str_var.get(),
                "hobby": [h for v, h in hobby_list if v.get()],
                "birthday": data_entry.entry.get()
            }
            print(data)
            content = []
            with open('../db/User.json', 'r', encoding='UTF-8') as f:
                content = json.load(f)
            content.append(data)
            with open('../db/User.json', 'w', encoding='UTF-8') as w:
                json.dump(content, w, ensure_ascii=False)
                messagebox.showwarning(message='注册成功！前往登录')
                root.destroy()

        tk.Label(root, text="").grid(row=9, column=2, sticky=tk.W)
        button01 = tk.Button(root, text='提交', width=20, command=get_info)
        button01.grid(row=10, column=2, sticky=tk.W)

        # button.config(command=get_info)

        root.mainloop()


if __name__ == '__main__':
    Register()
